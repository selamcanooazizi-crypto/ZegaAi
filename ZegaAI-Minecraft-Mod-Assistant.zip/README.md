# ZegaAİ — GitHub APK projesi

## APK oluşturma
Bu depo kökünü GitHub'a yükle. Actions > Build ZegaAI APK > çalıştırma > Artifacts > ZegaAI-APK.

## ZegaAİ çevrim içi sohbet
Uygulama adı ZegaAİ olarak kalır; Gemini entegrasyonu yoktur. Ayarlar > Çevrim içi yapay zekâ bölümünde OpenAI-uyumlu API adresi, model adı ve API anahtarı girilmelidir. Anahtar olmadan çevrim içi AI cevabı alınamaz. API anahtarı uygulamanın özel SharedPreferences alanında saklanır; üretim dağıtımında güvenli bir sunucu proxy'si kullanılması daha doğrudur.

## Minecraft modunu JAR yapma
`.github/workflows/mod-jar.yml` GitHub Actions üzerinden Gradle tabanlı bir Minecraft mod kaynak projesini derleyip JAR artifact'i çıkarır. Bu işlem yalnızca derlenebilir kaynak proje içindir (Fabric/Forge/NeoForge Gradle projesi, build.gradle(.kts), settings ve kaynaklar). Herhangi bir ZIP, Java dosyası veya başka bir mod JAR'ı otomatik olarak başka bir JAR'a dönüştürülemez. ZIP'in içinde zaten mod kaynak projesi olmalıdır. Workflow'u çalıştırmadan önce kaynak projeyi depo köküne yükle.

## Sınırlamalar
- Bu sürüm mod kodunu kendi başına yazıp test ederek sıfırdan mod üretmez; sohbet asistanı Minecraft/Fabric/Gradle konusunda yardımcı olur, mod derleme workflow'u kaynak projeyi derler.
- Android APK burada derlenip cihazda test edilmedi. GitHub Actions sonucu gerçek derleme doğrulaması olacaktır.
