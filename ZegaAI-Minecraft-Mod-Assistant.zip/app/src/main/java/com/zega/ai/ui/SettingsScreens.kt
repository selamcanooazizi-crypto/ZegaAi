package com.zega.ai.ui

import android.app.ActivityManager
import android.content.Context
import android.os.StatFs
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zega.ai.R
import com.zega.ai.ZegaViewModel
import com.zega.ai.ai.LocalModelManager
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubScaffold(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = cs.background,
                    titleContentColor = cs.onBackground,
                    navigationIconContentColor = cs.onBackground
                )
            )
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) { content() }
    }
}

@Composable
private fun SettingRow(icon: ImageVector, title: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(16.dp))
        Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
    }
}

@Composable
fun SettingsHome(onBack: () -> Unit, onOpen: (Screen) -> Unit) {
    SubScaffold(stringResource(R.string.settings), onBack) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            SettingRow(Icons.Filled.Language, stringResource(R.string.language)) { onOpen(Screen.LANGUAGE) }
            SettingRow(Icons.Filled.Palette, stringResource(R.string.theme)) { onOpen(Screen.THEME) }
            SettingRow(Icons.Filled.Cloud, "Çevrim içi yapay zekâ") { onOpen(Screen.ONLINE_AI) }
            SettingRow(Icons.Filled.Memory, stringResource(R.string.model_management)) { onOpen(Screen.MODEL) }
            SettingRow(Icons.Filled.History, stringResource(R.string.history)) { onOpen(Screen.HISTORY) }
            SettingRow(Icons.Filled.Storage, stringResource(R.string.storage)) { onOpen(Screen.STORAGE) }
            SettingRow(Icons.Filled.Mic, stringResource(R.string.voice_settings)) { onOpen(Screen.VOICE) }
            SettingRow(Icons.Filled.Info, stringResource(R.string.about)) { onOpen(Screen.ABOUT) }
        }
    }
}

// ---------------------------------------------------------------- Theme

@Composable
private fun themeName(id: String): String = when (id) {
    "BLACK" -> stringResource(R.string.theme_black)
    "DARKGRAY" -> stringResource(R.string.theme_darkgray)
    "DARKBLUE" -> stringResource(R.string.theme_darkblue)
    "PURPLE" -> stringResource(R.string.theme_purple)
    "GREEN" -> stringResource(R.string.theme_green)
    "WHITE" -> stringResource(R.string.theme_white)
    else -> stringResource(R.string.theme_custom)
}

@Composable
fun ThemeScreen(vm: ZegaViewModel, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val initial = remember {
        FloatArray(3).also { android.graphics.Color.colorToHSV(vm.customColor, it) }
    }
    var h by remember { mutableFloatStateOf(initial[0]) }
    var s by remember { mutableFloatStateOf(initial[1]) }
    var v by remember { mutableFloatStateOf(initial[2]) }

    fun applyCustom() {
        vm.updateCustomColor(Color.hsv(h, s, v).toArgb())
        vm.setTheme("CUSTOM")
    }

    SubScaffold(stringResource(R.string.theme), onBack) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            THEME_IDS.forEach { id ->
                val pal = paletteFor(id, if (id == "CUSTOM") Color.hsv(h, s, v).toArgb() else 0)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { if (id == "CUSTOM") applyCustom() else vm.setTheme(id) }
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(32.dp)
                            .background(pal.bg, CircleShape)
                            .border(BorderStroke(2.dp, pal.accent), CircleShape)
                    )
                    Spacer(Modifier.width(16.dp))
                    Text(themeName(id), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    if (vm.themeId == id) {
                        Icon(Icons.Filled.Check, contentDescription = null, tint = cs.primary)
                    }
                }
            }
            if (vm.themeId == "CUSTOM") {
                Column(Modifier.padding(horizontal = 20.dp)) {
                    Text(stringResource(R.string.custom_hue))
                    Slider(value = h, onValueChange = { h = it; applyCustom() }, valueRange = 0f..360f)
                    Text(stringResource(R.string.custom_sat))
                    Slider(value = s, onValueChange = { s = it; applyCustom() }, valueRange = 0f..1f)
                    Text(stringResource(R.string.custom_val))
                    Slider(value = v, onValueChange = { v = it; applyCustom() }, valueRange = 0f..1f)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Language

private val LANGUAGES = listOf(
    "tr" to "Türkçe",
    "en" to "English",
    "de" to "Deutsch",
    "ru" to "Русский",
    "fr" to "Français",
    "es" to "Español",
    "ar" to "العربية",
    "it" to "Italiano",
    "pt" to "Português"
)

@Composable
fun LanguageScreen(vm: ZegaViewModel, onBack: () -> Unit) {
    SubScaffold(stringResource(R.string.language), onBack) {
        LazyColumn {
            items(LANGUAGES) { (tag, name) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { if (vm.language != tag) vm.updateLanguage(tag) }
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(name, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
                    if (vm.language == tag) {
                        Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Model

private fun fmtBytes(b: Long): String {
    val gb = b / (1024.0 * 1024.0 * 1024.0)
    return if (gb >= 1.0) String.format(Locale.US, "%.1f GB", gb)
    else String.format(Locale.US, "%.0f MB", b / (1024.0 * 1024.0))
}

/** Very rough guide only: Q4 GGUF models need roughly 0.6-0.7 GB RAM per billion parameters plus overhead. */
private fun suggestedModelSize(totalRamBytes: Long): String {
    val gb = totalRamBytes / (1024.0 * 1024.0 * 1024.0)
    return when {
        gb < 3 -> "≤ 1B"
        gb < 5 -> "≤ 2B"
        gb < 8 -> "≤ 3B"
        gb < 12 -> "≤ 7B"
        else -> "≤ 8B"
    }
}

@Composable
private fun modelErrorText(code: String, arg: String): String = when (code) {
    "NOT_GGUF" -> stringResource(R.string.model_err_not_gguf)
    "TOO_BIG" -> stringResource(R.string.model_err_too_big, arg)
    "NO_SPACE" -> stringResource(R.string.model_err_no_space, arg)
    "CPU" -> stringResource(R.string.model_err_cpu)
    "ENGINE_MISSING" -> stringResource(R.string.err_engine_missing)
    "CRASHED" -> stringResource(R.string.model_err_crashed)
    "COPY" -> stringResource(R.string.model_err_copy, arg)
    else -> stringResource(R.string.model_err_load, arg)
}

@Composable
fun ModelScreen(vm: ZegaViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    val free = try {
        StatFs(ctx.filesDir.path).availableBytes
    } catch (e: Exception) {
        0L
    }
    val m = vm.model
    var confirmRemove by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    val busy = m.state == LocalModelManager.State.COPYING || m.state == LocalModelManager.State.LOADING

    SubScaffold(stringResource(R.string.model_management), onBack) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            InfoCard(stringResource(R.string.model_device, fmtBytes(mi.totalMem), fmtBytes(free)))
            InfoCard(stringResource(R.string.model_recommend, suggestedModelSize(mi.totalMem)))

            // ---- current model status ----
            val name = m.name
            val statusText = when (m.state) {
                LocalModelManager.State.NONE -> stringResource(R.string.model_none)
                LocalModelManager.State.COPYING -> stringResource(R.string.model_copying, m.progress)
                LocalModelManager.State.LOADING -> stringResource(R.string.model_loading)
                LocalModelManager.State.READY -> stringResource(R.string.model_loaded, name ?: "", fmtBytes(m.sizeBytes))
                LocalModelManager.State.ERROR ->
                    if (name != null) stringResource(R.string.model_failed_named, name) else stringResource(R.string.model_none)
            }
            InfoCard(statusText)
            if (m.state == LocalModelManager.State.COPYING) {
                LinearProgressIndicator(progress = { m.progress / 100f }, modifier = Modifier.fillMaxWidth())
            } else if (m.state == LocalModelManager.State.LOADING) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            val code = m.errorCode
            if (code != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Text(
                        modelErrorText(code, m.errorArg),
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Button(
                onClick = { picker.launch(arrayOf("*/*")) },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.model_select)) }

            if (m.state == LocalModelManager.State.ERROR && name != null && code != "NOT_GGUF") {
                OutlinedButton(
                    onClick = { vm.reloadModel() },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.model_retry)) }
            }
            if (name != null && !busy) {
                OutlinedButton(
                    onClick = { confirmRemove = true },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.model_remove)) }
            }
            InfoCard(stringResource(R.string.model_offline_note))
        }
    }
    if (confirmRemove) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            title = { Text(stringResource(R.string.model_remove)) },
            text = { Text(stringResource(R.string.model_remove_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    vm.removeModel()
                    confirmRemove = false
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmRemove = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

@Composable
private fun InfoCard(text: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Text(text, modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
    }
}

// ---------------------------------------------------------------- History / Storage

@Composable
private fun DeleteAllDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.delete_all)) },
        text = { Text(stringResource(R.string.delete_all_confirm)) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text(stringResource(R.string.delete)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}

@Composable
fun HistoryScreen(vm: ZegaViewModel, onBack: () -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    SubScaffold(stringResource(R.string.history), onBack) {
        Column(Modifier.fillMaxSize()) {
            if (vm.chats.isEmpty()) {
                Text(
                    stringResource(R.string.no_chats),
                    modifier = Modifier.padding(20.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(vm.chats, key = { it.id }) { chat ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(chat.title, modifier = Modifier.weight(1f), maxLines = 1)
                            IconButton(onClick = { vm.deleteChat(chat.id) }) {
                                Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.delete))
                            }
                        }
                    }
                }
                Button(
                    onClick = { confirm = true },
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) { Text(stringResource(R.string.delete_all)) }
            }
        }
    }
    if (confirm) {
        DeleteAllDialog(
            onConfirm = {
                vm.deleteAllChats()
                confirm = false
            },
            onDismiss = { confirm = false }
        )
    }
}

@Composable
fun StorageScreen(vm: ZegaViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    val free = try {
        StatFs(ctx.filesDir.path).availableBytes
    } catch (e: Exception) {
        0L
    }
    // Reading vm.chats makes this recompose (and re-read the size) after deletions.
    @Suppress("UNUSED_VARIABLE") val count = vm.chats.size
    SubScaffold(stringResource(R.string.storage), onBack) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            InfoCard(stringResource(R.string.storage_chats, fmtBytes(vm.storageBytes())))
            InfoCard(stringResource(R.string.storage_free, fmtBytes(free)))
            Button(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.delete_all))
            }
        }
    }
    if (confirm) {
        DeleteAllDialog(
            onConfirm = {
                vm.deleteAllChats()
                confirm = false
            },
            onDismiss = { confirm = false }
        )
    }
}

// ---------------------------------------------------------------- Voice / About

@Composable
fun VoiceScreen(onBack: () -> Unit) {
    SubScaffold(stringResource(R.string.voice_settings), onBack) {
        Column(Modifier.padding(20.dp)) { InfoCard(stringResource(R.string.voice_status)) }
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val version = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }
    SubScaffold(stringResource(R.string.about), onBack) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ZegaLogo(96.dp)
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineSmall)
            Text(stringResource(R.string.about_version, version))
            InfoCard(stringResource(R.string.about_desc))
        }
    }
}
