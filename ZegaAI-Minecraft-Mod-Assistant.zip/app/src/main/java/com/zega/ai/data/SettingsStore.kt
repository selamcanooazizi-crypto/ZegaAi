package com.zega.ai.data

import android.content.Context

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("zega_settings", Context.MODE_PRIVATE)

    var theme: String
        get() = prefs.getString("theme", "BLACK") ?: "BLACK"
        set(value) {
            prefs.edit().putString("theme", value).apply()
        }

    var customColor: Int
        get() = prefs.getInt("custom_color", 0xFF2A1F4D.toInt())
        set(value) {
            prefs.edit().putInt("custom_color", value).apply()
        }

    /** BCP-47 tag. Turkish is the default language. */
    var language: String
        get() = prefs.getString("language", "tr") ?: "tr"
        set(value) {
            prefs.edit().putString("language", value).apply()
        }

    var aiApiBase: String
        get() = prefs.getString("ai_api_base", "https://api.openai.com/v1/chat/completions") ?: "https://api.openai.com/v1/chat/completions"
        set(value) { prefs.edit().putString("ai_api_base", value).apply() }

    var aiApiKey: String
        get() = prefs.getString("ai_api_key", "") ?: ""
        set(value) { prefs.edit().putString("ai_api_key", value).apply() }

    var aiModel: String
        get() = prefs.getString("ai_model", "gpt-4o-mini") ?: "gpt-4o-mini"
        set(value) { prefs.edit().putString("ai_model", value).apply() }

    /** Absolute path of the imported GGUF model inside the app's private storage ("" = none). */
    var modelPath: String
        get() = prefs.getString("model_path", "") ?: ""
        set(value) {
            prefs.edit().putString("model_path", value).apply()
        }

    var modelName: String
        get() = prefs.getString("model_name", "") ?: ""
        set(value) {
            prefs.edit().putString("model_name", value).apply()
        }

    /**
     * Crash guard: true while native model loading is in progress. It is written synchronously
     * (commit) so it survives a native crash; if it is still set on the next start, the model
     * is not loaded automatically (prevents a crash loop).
     */
    var modelLoading: Boolean
        get() = prefs.getBoolean("model_loading", false)
        set(value) {
            prefs.edit().putBoolean("model_loading", value).commit()
        }
}
