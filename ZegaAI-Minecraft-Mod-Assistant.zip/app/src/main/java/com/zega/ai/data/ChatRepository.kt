package com.zega.ai.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Stores chat history as a JSON file in the app's private storage. */
class ChatRepository(private val context: Context) {

    private val file: File get() = File(context.filesDir, "chats.json")

    fun load(): List<Chat> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ms = o.getJSONArray("messages")
                Chat(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    messages = (0 until ms.length()).map { j ->
                        val m = ms.getJSONObject(j)
                        ChatMessage(
                            id = m.getString("id"),
                            role = m.getString("role"),
                            text = m.getString("text"),
                            time = m.getLong("time"),
                            isError = m.optBoolean("error", false)
                        )
                    },
                    updated = o.getLong("updated")
                )
            }
        } catch (e: Exception) {
            // Keep the unreadable file instead of silently overwriting it.
            file.renameTo(File(context.filesDir, "chats.corrupt.json"))
            emptyList()
        }
    }

    fun save(chats: List<Chat>) {
        val arr = JSONArray()
        chats.forEach { c ->
            val ms = JSONArray()
            c.messages.forEach { m ->
                ms.put(
                    JSONObject()
                        .put("id", m.id)
                        .put("role", m.role)
                        .put("text", m.text)
                        .put("time", m.time)
                        .put("error", m.isError)
                )
            }
            arr.put(
                JSONObject()
                    .put("id", c.id)
                    .put("title", c.title)
                    .put("updated", c.updated)
                    .put("messages", ms)
            )
        }
        val tmp = File(context.filesDir, "chats.json.tmp")
        tmp.writeText(arr.toString())
        if (!tmp.renameTo(file)) {
            file.delete()
            tmp.renameTo(file)
        }
    }

    fun sizeBytes(): Long = if (file.exists()) file.length() else 0L
}
