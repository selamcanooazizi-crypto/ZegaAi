import com.zega.ai.ai.*;
import java.nio.file.*;
import java.io.ByteArrayOutputStream;
public class Test {
  static int fails=0;
  // true if the chunk ends with a valid lead byte whose continuation bytes are missing
  static boolean truncated(byte[] b){
    int n=b.length;
    for(int back=1;back<=Math.min(4,n);back++){
      int c=b[n-back]&0xFF;
      if((c&0xC0)==0x80) continue;
      int need = c<0x80?1: (c>=0xC2&&c<=0xDF)?2: (c>=0xE0&&c<=0xEF)?3: (c>=0xF0&&c<=0xF4)?4: 1;
      return back<need;
    }
    return false;
  }
  static void check(boolean c,String m){ System.out.println((c?"PASS ":"FAIL ")+m); if(!c) fails++; }
  public static void main(String[] a) throws Exception {
    System.load(a[0]);
    LlamaBridge b = new LlamaBridge();
    check(truncated(new byte[]{(byte)0xF0,(byte)0x9F}) && !truncated("😀".getBytes("UTF-8")) && !truncated("ğ".getBytes("UTF-8")), "checker self-test");
    // 1) generate without model
    String e = b.generate(new String[]{"user"}, new String[]{"hi"}, 8, bytes->true);
    check("NO_MODEL".equals(e), "generate before load -> NO_MODEL ("+e+")");
    // 2) bad files
    e = b.load("/nonexistent.gguf", 512, 2);
    check(e!=null, "missing file -> error: "+e);
    Files.write(Paths.get("junk.gguf"), "not a gguf at all, just text".getBytes());
    e = b.load("junk.gguf", 512, 2);
    check(e!=null, "junk file -> error: "+e);
    // 3) real load
    e = b.load(a[1], 512, 2);
    check(e==null, "load tiny.gguf -> "+e);
    // 4) generate with ChatML template, emoji + Turkish input
    ByteArrayOutputStream out=new ByteArrayOutputStream(); int[] n={0};
    long t=System.currentTimeMillis();
    e = b.generate(new String[]{"system","user"}, new String[]{"Sen yardımcı bir asistansın.","Merhaba dünya 😀 çğışöü"}, 40, bytes->{ out.write(bytes,0,bytes.length); n[0]++; return true;});
    check(e==null, "generate #1 ok ("+e+"), callbacks="+n[0]+" bytes="+out.size()+" in "+(System.currentTimeMillis()-t)+"ms");
    check(n[0]>0 && out.size()>0, "tokens were produced");
    // every emitted chunk must be complete UTF-8 -> decoding strictly must succeed per chunk
    final boolean[] allValid={true}; final int[] chunks={0}; final byte[][] prev={null}; // last chunk is the final flush of a leftover partial sequence, so it is exempt
    e = b.generate(new String[]{"system","user"}, new String[]{"Sen yardımcı bir asistansın.","Merhaba dünya 😀 çğışöü"}, 120, bytes->{ chunks[0]++; if(prev[0]!=null && truncated(prev[0]) && (bytes[0]&0xC0)==0x80){ allValid[0]=false; } prev[0]=bytes; return true;});
    check(e==null && allValid[0] && chunks[0]>0, "generate #2 (same prompt -> KV prefix reuse): a valid multi-byte character is never split across callbacks ("+chunks[0]+" chunks)");
    // 5) multi-turn growth
    e = b.generate(new String[]{"system","user","assistant","user"}, new String[]{"s","q1","a1","q2"}, 20, bytes->true);
    check(e==null, "multi-turn generate ok ("+e+")");
    // 6) callback returns false -> stops early
    int[] c2={0};
    e = b.generate(new String[]{"user"}, new String[]{"count"}, 200, bytes->{ c2[0]++; return c2[0]<3; });
    check(e==null && c2[0]<=3, "callback false stops generation (callbacks="+c2[0]+")");
    // 7) stop() from another thread during long generation
    int[] c3={0};
    Thread stopper=new Thread(()->{ try{Thread.sleep(150);}catch(Exception x){} b.stop(); });
    t=System.currentTimeMillis(); stopper.start();
    e = b.generate(new String[]{"user"}, new String[]{"long"}, 400, bytes->{ c3[0]++; try{Thread.sleep(5);}catch(Exception x){} return true; });
    long dt=System.currentTimeMillis()-t;
    check(e==null && c3[0]<400 && dt<3000, "stop() from other thread ended generation early (callbacks="+c3[0]+", "+dt+"ms)");
    // 8) context overflow: huge single message -> error, not crash
    String big="x ".repeat(5000);
    e = b.generate(new String[]{"user"}, new String[]{big}, 50, bytes->true);
    check("CONTEXT_TOO_LONG".equals(e), "oversized prompt -> CONTEXT_TOO_LONG ("+e+")");
    // 9) old turns are dropped when history is long but last message fits
    String[] roles=new String[41], cont=new String[41];
    for(int i=0;i<41;i++){ roles[i]= i%2==0?"user":"assistant"; cont[i]="message number "+i+" with some padding words to use up tokens"; }
    e = b.generate(roles, cont, 30, bytes->true);
    check(e==null, "long history trimmed to fit context ("+e+")");
    // 10) still healthy after all of that, then unload / reload / unload twice
    e = b.generate(new String[]{"user"}, new String[]{"hello"}, 10, bytes->true);
    check(e==null, "generate still works after stress");
    b.unload(); b.unload();
    e = b.generate(new String[]{"user"}, new String[]{"hi"}, 8, bytes->true);
    check("NO_MODEL".equals(e), "after unload -> NO_MODEL");
    e = b.load(a[1], 512, 2);
    check(e==null, "reload ok");
    b.unload();
    System.out.println(fails==0?"ALL PASSED":"FAILURES: "+fails);
    System.exit(fails==0?0:1);
  }
}
