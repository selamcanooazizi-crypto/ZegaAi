package com.zega.ai.ai

/** Receives raw UTF-8 bytes of generated text. Return false to stop generation. */
fun interface TokenCallback {
    fun onToken(bytes: ByteArray): Boolean
}

/**
 * Thin JNI wrapper over llama.cpp (libzega_llm.so). All functions are blocking:
 * call them from a background thread, never from the main thread.
 */
object LlamaBridge {

    /** False when the native library could not be loaded (e.g. unsupported CPU architecture). */
    val available: Boolean = try {
        System.loadLibrary("zega_llm")
        true
    } catch (e: Throwable) {
        false
    }

    /** @return null on success, otherwise an error description. */
    external fun load(path: String, nCtx: Int, nThreads: Int): String?

    external fun unload()

    /** Safe to call at any time, also when the library failed to load. */
    fun stopAndUnload() {
        if (!available) return
        try {
            stop()
            unload()
        } catch (_: Throwable) {
        }
    }

    /** Asks a running [generate] call to return as soon as possible. */
    external fun stop()

    /**
     * @param roles "system" / "user" / "assistant" per message
     * @return null on success, otherwise an error description
     */
    external fun generate(
        roles: Array<String>,
        contents: Array<String>,
        maxNew: Int,
        callback: TokenCallback
    ): String?
}
