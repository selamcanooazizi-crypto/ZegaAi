# ZegaAI proguard rules (release minify is disabled, rules kept for when it is enabled)
-keep class com.zega.ai.ai.LlamaBridge { *; }
-keep interface com.zega.ai.ai.TokenCallback { *; }
-keepclassmembers class * implements com.zega.ai.ai.TokenCallback { public boolean onToken(byte[]); }
